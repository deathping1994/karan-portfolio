'use strict';

/**
 * @ngdoc function
 * @name deathping1994githubioApp.controller:AboutCtrl
 * @description
 * # AboutCtrl
 * Controller of the deathping1994githubioApp
 */
angular.module('deathping1994githubioApp')
  .controller('AboutCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
